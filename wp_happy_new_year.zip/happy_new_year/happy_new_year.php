<?php
/*
  * Plugin Name: Happy New Year
  * Description: Chúc mừng năm mới xuân kỷ hợi
  * Author: Tuyển Giảng
  * Version: 1.0.0
  */

define('URL_P', plugins_url('happy_new_year/assets/'));

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('style-hpny', URL_P . 'hpny.css');
    wp_enqueue_script('script-hpny',URL_P.'js/phao_hoa.js');
});

function header_cau_doi()
{
    ?>
    <img src="<?php echo "/wp-content/plugins/happy_new_year/assets/images/phaotrai2019.png" ?>" class="left-2019">
    <img src="<?php echo "/wp-content/plugins/happy_new_year/assets/images/phaophai2019.png" ?>" class="right-2019">
    <?php
}
function phao_hoa(){
    echo '<script type="text/javascript" src="/wp-content/plugins/happy_new_year/assets/js/phao_hoa.js"></script>';
}
add_action('wp_footer','header_cau_doi');
add_action('wp_footer','phao_hoa');

